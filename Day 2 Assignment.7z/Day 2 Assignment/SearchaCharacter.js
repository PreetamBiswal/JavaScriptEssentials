
let data = ["Facebook","Skype","Whatsaap","Reddit",
"Quora","Snapchat"];
let i;
for ( i = 0; i < data.length; i++)
 {
     let str = data[i];
     if (str.search("a") > 1)
     {
  
console.log("The occurence of a is" + data[i])
  
}
 }