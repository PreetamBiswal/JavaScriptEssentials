
let str = ["Facebook","Skype","Whatsaap","Reddit",
"Quora","Snapchat"];

console.log("The Array in reverse order ");

for ( let i = (str.length -1); i>=0; i--)
 {
    console.log(str[i]);  
}
 