let time = 60;
let TimeInSeconds;
TimeinSeconds = (time * 60);
console.log (TimeinSeconds);