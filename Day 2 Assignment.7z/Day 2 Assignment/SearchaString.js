let data = ["Facebook","Instagram","Whatsaap","Reddit","Quora","Snapchat"];

let searchaString = data.indexOf("Whatsaap");

console.log(`The occurence of searchString is ${searchaString}`);