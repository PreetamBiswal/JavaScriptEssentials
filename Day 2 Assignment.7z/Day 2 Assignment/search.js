

  let str = "Visit W3Schools!"; 
  let n = str.search("W");
  console.log (n);
