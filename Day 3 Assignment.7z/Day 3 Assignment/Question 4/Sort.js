let UserDetails = [{
    name: "Preetam",
    age: 28,
    country: "India",
    Hobbies: ["Coding", "Strengeth Training","Badminton","Painting"],
    },
    {
        name: "Parismita",
        age: 24,
        country: "India",
        },
        {
            name: "Pallavi",
            age: 30,
            country: "Germany",
            },
        ]
     function FilterAge () {  
         console.log("The objects whose age less than 30");
        for (let i = 0; i < UserDetails.length; i++) {
            if(UserDetails[i].age <30)   
            {
                console.log(UserDetails[i]);
            }
            } 
         
       }
       function FilterCountry () {  
           console.log("The object whose country is India");
        for (let i = 0; i < UserDetails.length; i++) {
            if(UserDetails[i].country == "India")   
            {
                console.log(UserDetails[i]);
            }
            } 
         
       }
 
 FilterAge();
 FilterCountry();