function replace() {
  const ele = document.getElementById('input1').value;
  document.getElementById("input2").value = ele;
 
}