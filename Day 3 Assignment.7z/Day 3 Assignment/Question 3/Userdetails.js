 let UserDetails = {
   name: "Preetam",
   age: 28,
   country: "India",
   Hobbies: ["Coding", "Strengeth Training","Badminton","Painting"],
   }

    function Mydetails () {   
       console.log(UserDetails);   
      }

Mydetails();