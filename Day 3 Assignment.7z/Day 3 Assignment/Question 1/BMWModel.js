

<button onclick="document.getElementById('BMW').src='BMW Black.jpg'"> BMW VBX6 Black Model</button>

<img id="BMW" src="BMW White.jpg" style="width:100px">

<button onclick="document.getElementById('BMW').src='BMW White.jpg'"> BMW VBX6 Black Model</button>

<button onclick="document.getElementById('BMW').src='BMW White.jpg'"> Previous </button>